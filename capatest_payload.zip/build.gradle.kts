// Top-level Gradle build file intentionally minimal for AGP via app module.
